var N = null;var sourcesIndex = {};
sourcesIndex['doc'] = {"name":"","dirs":[],"files":["doc.rs"]};
