var ALIASES = {};
ALIASES['doc'] = {};
